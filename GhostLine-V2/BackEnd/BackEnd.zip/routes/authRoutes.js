// Auth routes logic
