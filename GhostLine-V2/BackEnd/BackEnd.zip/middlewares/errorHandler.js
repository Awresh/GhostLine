// Error handling middleware
