// Auth middleware logic
