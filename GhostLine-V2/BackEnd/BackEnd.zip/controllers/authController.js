// Auth controller logic
