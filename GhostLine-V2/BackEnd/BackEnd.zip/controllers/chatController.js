// Chat controller logic
