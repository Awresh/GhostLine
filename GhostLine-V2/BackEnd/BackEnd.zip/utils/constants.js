// Constants definition
