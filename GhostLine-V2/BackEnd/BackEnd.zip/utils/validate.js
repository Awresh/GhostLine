// Validation utility
